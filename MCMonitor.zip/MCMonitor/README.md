# Minecraft服务器监控应用

基于HarmonyOS的Minecraft服务器状态监控应用，支持实时监控多个Minecraft服务器的在线状态、延迟、玩家数量等信息。

## 功能特性

- 📊 服务器状态监控（在线/离线、延迟、玩家数量）
- 🔄 自动刷新服务器状态
- ➕ 支持添加多个服务器
- 📱 响应式UI设计，支持手机和平板
- 🌐 网络状态检测和错误处理

## 项目结构

```
MCMonitor/
├── AppScope/                 # 应用全局配置
│   ├── app.json5            # 应用配置
│   └── resources/           # 全局资源
├── entry/                   # 主模块
│   ├── src/main/
│   │   ├── ets/
│   │   │   ├── entryability/ # 应用入口
│   │   │   ├── pages/        # 页面组件
│   │   │   └── model/        # 数据模型
│   │   └── resources/        # 模块资源
│   └── module.json5          # 模块配置
├── build-profile.json5       # 构建配置
├── hvigorfile.ts            # 构建脚本
└── oh-package.json5         # 依赖管理
```

## 技术栈

- **开发语言**: ArkTS
- **UI框架**: ArkUI
- **目标平台**: HarmonyOS (API 10+)
- **构建工具**: Hvigor

## 快速开始

1. 确保已安装HarmonyOS SDK和DevEco Studio
2. 克隆或下载项目代码
3. 使用DevEco Studio打开项目
4. 连接设备或启动模拟器
5. 点击运行按钮构建并安装应用

## 页面说明

### 主页 (HomePage)
- 显示所有已添加的服务器列表
- 支持手动刷新单个或全部服务器
- 显示服务器的基本状态信息

### 我的页面 (MyPage)
- 用户信息展示
- 应用功能入口（添加服务器、设置等）

### 添加服务器页面 (AddServerPage)
- 表单方式添加新的Minecraft服务器
- 支持自定义服务器名称、地址和端口
- 提供快速添加示例服务器功能

### 服务器详情页面 (ServerDetailPage)
- 显示服务器的详细信息
- 包括延迟、玩家列表、服务器描述等
- 支持手动刷新状态

## 数据模型

### ServerManager
管理服务器列表，提供增删改查和状态刷新功能

### MinecraftServer
实现Minecraft服务器状态查询逻辑

## 注意事项

- 应用需要网络权限来查询服务器状态
- 当前版本使用模拟数据进行演示
- 实际服务器查询功能需要实现Minecraft服务器通信协议

## 开发计划

- [ ] 实现真实的Minecraft服务器通信
- [ ] 添加局域网服务器发现功能
- [ ] 实现数据持久化存储
- [ ] 添加通知功能
- [ ] 支持更多服务器信息显示

## 许可证

Apache License 2.0