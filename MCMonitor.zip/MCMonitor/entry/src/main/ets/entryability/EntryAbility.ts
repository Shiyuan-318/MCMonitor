  import UIAbility from '@ohos.app.ability.UIAbility';
import window from '@ohos.window';
import Want from '@ohos.app.ability.Want';
import AbilityConstant from '@ohos.app.ability.AbilityConstant';
import { ServerManager } from '../model/ServerManager';

export default class EntryAbility extends UIAbility {
  onCreate(want: Want, launchParam: AbilityConstant.LaunchParam): void {
    console.info('EntryAbility onCreate');
    
    // 初始化服务器管理器
    ServerManager.initialize().then(() => {
      console.info('ServerManager initialized successfully');
    }).catch((error) => {
      console.error('Failed to initialize ServerManager:', error);
    });
  }

  onDestroy(): void {
    console.info('EntryAbility onDestroy');
    
    // 停止自动刷新
    ServerManager.stopAutoRefresh();
  }

  onWindowStageCreate(windowStage: window.WindowStage): void {
    console.info('EntryAbility onWindowStageCreate');

    windowStage.loadContent('pages/Index', (err, data) => {
      if (err.code) {
        console.error('Failed to load the content. Cause: ' + JSON.stringify(err));
        return;
      }
      console.info('Succeeded in loading the content. Data: ' + JSON.stringify(data));
    });
  }

  onWindowStageDestroy(): void {
    console.info('EntryAbility onWindowStageDestroy');
  }

  onForeground(): void {
    console.info('EntryAbility onForeground');
    
    // 应用回到前台时刷新服务器状态
    ServerManager.refreshAllServers().catch(() => {});
  }

  onBackground(): void {
    console.info('EntryAbility onBackground');
  }
}