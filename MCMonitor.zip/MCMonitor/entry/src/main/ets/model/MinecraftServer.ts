import socket from '@ohos.net.socket';

export interface ServerStatus {
  online: boolean;
  ping: number;
  motd: string;
  players: {
    online: number;
    max: number;
    list?: string[];
  };
  version?: string;
  favicon?: string;
  mods?: string[];
}

export class MinecraftServer {
  private static readonly PACKET_ID_HANDSHAKE = 0x00;
  private static readonly PACKET_ID_STATUS_REQUEST = 0x00;
  private static readonly PACKET_ID_STATUS_RESPONSE = 0x00;
  private static readonly PROTOCOL_VERSION = 754; // 1.16.5

  static async ping(address: string, port: number = 25565, timeout: number = 5000): Promise<ServerStatus> {
    return new Promise((resolve, reject) => {
      const timeoutId = setTimeout(() => {
        reject(new Error('Connection timeout'));
      }, timeout);

      this.queryServer(address, port).then((status: ServerStatus) => {
        clearTimeout(timeoutId);
        resolve(status);
      }).catch((error: Error) => {
        clearTimeout(timeoutId);
        reject(error);
      });
    });
  }

  private static async queryServer(address: string, port: number): Promise<ServerStatus> {
    try {
      // 创建TCP socket
      const tcpSocket = socket.constructTCPSocketInstance();
      
      // 连接服务器
      await tcpSocket.connect({
        address: address,
        port: port,
        timeout: 5000
      });

      const startTime = Date.now();
      
      // 发送握手包
      await this.sendHandshake(tcpSocket, address, port);
      
      // 发送状态请求
      await this.sendStatusRequest(tcpSocket);
      
      // 接收状态响应
      const response = await this.receiveStatusResponse(tcpSocket);
      const ping = Date.now() - startTime;

      // 关闭连接
      tcpSocket.close();

      // 解析响应数据
      return this.parseStatusResponse(response, ping);
    } catch (error) {
      console.error(`Failed to query server ${address}:${port}:`, error);
      throw new Error(`Failed to connect to server: ${error.message}`);
    }
  }

  private static async sendHandshake(tcpSocket: socket.TCPSocket, address: string, port: number): Promise<void> {
    const handshakePacket = this.createHandshakePacket(address, port);
    await tcpSocket.send({
      data: handshakePacket
    });
  }

  private static async sendStatusRequest(tcpSocket: socket.TCPSocket): Promise<void> {
    const requestPacket = this.createStatusRequestPacket();
    await tcpSocket.send({
      data: requestPacket
    });
  }

  private static async receiveStatusResponse(tcpSocket: socket.TCPSocket): Promise<Uint8Array> {
    return new Promise((resolve, reject) => {
      const chunks: Uint8Array[] = [];
      let totalLength = 0;

      tcpSocket.on('message', (value: { message: ArrayBuffer, remoteInfo: socket.SocketRemoteInfo }) => {
        const chunk = new Uint8Array(value.message);
        chunks.push(chunk);
        totalLength += chunk.length;

        try {
          // 尝试解析响应长度
          const combined = new Uint8Array(totalLength);
          let offset = 0;
          for (const chunk of chunks) {
            combined.set(chunk, offset);
            offset += chunk.length;
          }

          // 检查是否收到完整响应
          if (this.isCompleteResponse(combined)) {
            resolve(combined);
          }
        } catch (error) {
          reject(error);
        }
      });

      tcpSocket.on('error', (err: BusinessError) => {
        reject(new Error(`Socket error: ${err.message}`));
      });
    });
  }

  private static createHandshakePacket(address: string, port: number): Uint8Array {
    const packetData: number[] = [];
    
    // 包ID (VarInt)
    this.writeVarInt(packetData, this.PACKET_ID_HANDSHAKE);
    
    // 协议版本 (VarInt)
    this.writeVarInt(packetData, this.PROTOCOL_VERSION);
    
    // 服务器地址 (String)
    this.writeString(packetData, address);
    
    // 服务器端口 (Unsigned Short)
    packetData.push((port >> 8) & 0xFF);
    packetData.push(port & 0xFF);
    
    // 下一个状态 (VarInt) - 1 for status
    this.writeVarInt(packetData, 1);
    
    // 添加包长度前缀
    const lengthData: number[] = [];
    this.writeVarInt(lengthData, packetData.length);
    
    const finalData = [...lengthData, ...packetData];
    return new Uint8Array(finalData);
  }

  private static createStatusRequestPacket(): Uint8Array {
    const packetData: number[] = [];
    
    // 包ID (VarInt)
    this.writeVarInt(packetData, this.PACKET_ID_STATUS_REQUEST);
    
    // 添加包长度前缀
    const lengthData: number[] = [];
    this.writeVarInt(lengthData, packetData.length);
    
    const finalData = [...lengthData, ...packetData];
    return new Uint8Array(finalData);
  }

  private static writeVarInt(data: number[], value: number): void {
    do {
      let temp = value & 0x7F;
      value >>>= 7;
      if (value !== 0) {
        temp |= 0x80;
      }
      data.push(temp);
    } while (value !== 0);
  }

  private static writeString(data: number[], str: string): void {
    // 使用HarmonyOS兼容的方式编码字符串
    const strBytes = this.stringToBytes(str);
    this.writeVarInt(data, strBytes.length);
    data.push(...strBytes);
  }

  private static stringToBytes(str: string): number[] {
    const bytes: number[] = [];
    for (let i = 0; i < str.length; i++) {
      const code = str.charCodeAt(i);
      if (code < 0x80) {
        bytes.push(code);
      } else if (code < 0x800) {
        bytes.push(0xC0 | (code >> 6));
        bytes.push(0x80 | (code & 0x3F));
      } else {
        bytes.push(0xE0 | (code >> 12));
        bytes.push(0x80 | ((code >> 6) & 0x3F));
        bytes.push(0x80 | (code & 0x3F));
      }
    }
    return bytes;
  }

  private static bytesToString(bytes: Uint8Array): string {
    let result = '';
    let i = 0;
    while (i < bytes.length) {
      const byte1 = bytes[i++];
      if (byte1 < 0x80) {
        result += String.fromCharCode(byte1);
      } else if (byte1 < 0xE0) {
        const byte2 = bytes[i++];
        result += String.fromCharCode(((byte1 & 0x1F) << 6) | (byte2 & 0x3F));
      } else {
        const byte2 = bytes[i++];
        const byte3 = bytes[i++];
        result += String.fromCharCode(((byte1 & 0x0F) << 12) | ((byte2 & 0x3F) << 6) | (byte3 & 0x3F));
      }
    }
    return result;
  }

  private static isCompleteResponse(data: Uint8Array): boolean {
    try {
      let position = 0;
      const length = this.readVarInt(data, position);
      position += this.getVarIntLength(length);
      return data.length >= length + position;
    } catch {
      return false;
    }
  }

  private static readVarInt(data: Uint8Array, startPosition: number): number {
    let value = 0;
    let position = 0;
    let currentByte;

    let index = startPosition;
    while (true) {
      currentByte = data[index++];
      value |= (currentByte & 0x7F) << position;

      if ((currentByte & 0x80) === 0) break;

      position += 7;
      if (position >= 32) {
        throw new Error('VarInt is too big');
      }
    }

    return value;
  }

  private static getVarIntLength(value: number): number {
    let length = 0;
    do {
      value >>>= 7;
      length++;
    } while (value !== 0);
    return length;
  }

  private static parseStatusResponse(data: Uint8Array, ping: number): ServerStatus {
    try {
      let position = 0;
      
      // 读取包长度
      const packetLength = this.readVarInt(data, position);
      position += this.getVarIntLength(packetLength);
      
      // 读取包ID
      const packetId = this.readVarInt(data, position);
      position += this.getVarIntLength(packetId);
      
      if (packetId !== this.PACKET_ID_STATUS_RESPONSE) {
        throw new Error('Invalid packet ID');
      }
      
      // 读取JSON响应长度
      const jsonLength = this.readVarInt(data, position);
      position += this.getVarIntLength(jsonLength);
      
      // 读取JSON数据
      const jsonBytes = data.slice(position, position + jsonLength);
      const jsonData = this.bytesToString(jsonBytes);
      const status = JSON.parse(jsonData);
      
      return {
        online: true,
        ping: ping,
        motd: this.cleanMotd(status.description?.text || status.description || 'A Minecraft Server'),
        players: {
          online: status.players?.online || 0,
          max: status.players?.max || 0,
          list: status.players?.sample?.map((player: any) => player.name) || []
        },
        version: status.version?.name || 'Unknown',
        favicon: status.favicon || ''
      };
    } catch (error) {
      console.error('Failed to parse status response:', error);
      // 返回基本状态信息
      return {
        online: true,
        ping: ping,
        motd: 'A Minecraft Server',
        players: {
          online: 0,
          max: 0
        },
        version: 'Unknown'
      };
    }
  }

  private static cleanMotd(motd: string): string {
    // 移除颜色代码和格式字符
    return motd.replace(/§[0-9a-fk-or]/g, '').trim();
  }

  static async scanNetwork(range: string): Promise<string[]> {
    // 实现局域网服务器扫描（简化版）
    console.log('Network scanning not implemented yet');
    return Promise.resolve([]);
  }
}