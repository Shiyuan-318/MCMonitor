import { MinecraftServer, ServerStatus } from './MinecraftServer';

export interface ServerInfo {
  id: string;
  name: string;
  address: string;
  port: number;
  online: boolean;
  ping: number;
  motd: string;
  players: {
    online: number;
    max: number;
    list?: string[];
  };
  version?: string;
  favicon?: string;
  lastUpdated: number;
  error?: string;
}

export class ServerManager {
  private static servers: Map<string, ServerInfo> = new Map();
  private static autoRefreshInterval: number | null = null;
  private static readonly REFRESH_INTERVAL = 30000; // 30秒

  static async initialize(): Promise<void> {
    try {
      // 从本地存储加载服务器列表
      await this.loadServersFromStorage();
      
      // 启动自动刷新
      this.startAutoRefresh();
      
      console.info('ServerManager initialized successfully');
    } catch (error) {
      console.error('Failed to initialize ServerManager:', error);
      throw error;
    }
  }

  static async addServer(name: string, address: string, port: number = 25565): Promise<ServerInfo> {
    try {
      // 验证输入
      if (!name || !name.trim()) {
        throw new Error('服务器名称不能为空');
      }
      
      if (!address || !address.trim()) {
        throw new Error('服务器地址不能为空');
      }
      
      if (!port || port < 1 || port > 65535) {
        throw new Error('端口号必须在1-65535之间');
      }

      // 检查是否已存在相同地址的服务器
      for (const server of this.servers.values()) {
        if (server.address === address && server.port === port) {
          throw new Error('该服务器已存在');
        }
      }

      const id = this.generateId();
      const serverInfo: ServerInfo = {
        id: id,
        name: name.trim(),
        address: address.trim(),
        port: port,
        online: false,
        ping: 0,
        motd: '',
        players: { online: 0, max: 0 },
        lastUpdated: Date.now()
      };

      // 立即查询服务器状态
      await this.refreshServer(id);

      this.servers.set(id, serverInfo);
      await this.saveServersToStorage();

      return serverInfo;
    } catch (error) {
      console.error('Failed to add server:', error);
      throw error;
    }
  }

  static async refreshServer(serverId: string): Promise<ServerInfo> {
    try {
      const server = this.servers.get(serverId);
      if (!server) {
        throw new Error('服务器不存在');
      }

      console.log(`Refreshing server: ${server.name} (${server.address}:${server.port})`);

      const status = await MinecraftServer.ping(server.address, server.port, 10000);
      
      const updatedServer: ServerInfo = {
        ...server,
        online: status.online,
        ping: status.ping,
        motd: status.motd,
        players: status.players,
        version: status.version,
        favicon: status.favicon,
        lastUpdated: Date.now(),
        error: undefined
      };

      this.servers.set(serverId, updatedServer);
      await this.saveServersToStorage();

      return updatedServer;
    } catch (error) {
      console.error(`Failed to refresh server ${serverId}:`, error);
      
      // 更新错误信息
      const server = this.servers.get(serverId);
      if (server) {
        const errorServer: ServerInfo = {
          ...server,
          online: false,
          error: error.message || '连接失败',
          lastUpdated: Date.now()
        };
        this.servers.set(serverId, errorServer);
        await this.saveServersToStorage();
        
        throw error;
      }
      
      throw new Error('服务器不存在');
    }
  }

  static async refreshAllServers(): Promise<void> {
    console.log('Refreshing all servers...');
    
    const promises: Promise<ServerInfo | void>[] = [];
    
    for (const serverId of this.servers.keys()) {
      promises.push(
        this.refreshServer(serverId).catch((error) => {
          console.error(`Failed to refresh server ${serverId}:`, error);
        })
      );
    }

    await Promise.all(promises);
    console.log('All servers refreshed');
  }

  static removeServer(serverId: string): void {
    try {
      if (this.servers.has(serverId)) {
        this.servers.delete(serverId);
        this.saveServersToStorage().catch(console.error);
        console.log(`Server ${serverId} removed`);
      }
    } catch (error) {
      console.error('Failed to remove server:', error);
      throw error;
    }
  }

  static getServer(serverId: string): ServerInfo | undefined {
    return this.servers.get(serverId);
  }

  static getAllServers(): ServerInfo[] {
    return Array.from(this.servers.values());
  }

  static getOnlineServers(): ServerInfo[] {
    return Array.from(this.servers.values()).filter(server => server.online);
  }

  static getOfflineServers(): ServerInfo[] {
    return Array.from(this.servers.values()).filter(server => !server.online);
  }

  static startAutoRefresh(): void {
    if (this.autoRefreshInterval) {
      this.stopAutoRefresh();
    }

    this.autoRefreshInterval = setInterval(() => {
      this.refreshAllServers().catch(console.error);
    }, this.REFRESH_INTERVAL) as unknown as number;

    console.log('Auto refresh started');
  }

  static stopAutoRefresh(): void {
    if (this.autoRefreshInterval) {
      clearInterval(this.autoRefreshInterval);
      this.autoRefreshInterval = null;
      console.log('Auto refresh stopped');
    }
  }

  private static generateId(): string {
    return 'server_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
  }

  private static async loadServersFromStorage(): Promise<void> {
    try {
      // 这里应该从本地存储加载数据
      // 目前使用内存存储作为示例
      const storedServers = this.getStoredServers();
      
      if (storedServers && storedServers.length > 0) {
        this.servers = new Map(storedServers.map(server => [server.id, server]));
        console.log(`Loaded ${storedServers.length} servers from storage`);
      } else {
        // 添加示例服务器
        await this.addExampleServers();
      }
    } catch (error) {
      console.error('Failed to load servers from storage:', error);
      // 添加示例服务器作为后备
      await this.addExampleServers();
    }
  }

  private static async saveServersToStorage(): Promise<void> {
    try {
      const servers = Array.from(this.servers.values());
      // 这里应该保存到本地存储
      console.log(`Saved ${servers.length} servers to storage`);
    } catch (error) {
      console.error('Failed to save servers to storage:', error);
    }
  }

  private static getStoredServers(): ServerInfo[] {
    // 模拟从本地存储获取数据
    // 实际应用中应该使用HarmonyOS的持久化存储API
    return [];
  }

  private static async addExampleServers(): Promise<void> {
    try {
      // 添加一些示例服务器
      const exampleServers = [
        { name: 'Hypixel', address: 'mc.hypixel.net', port: 25565 },
        { name: 'Mineplex', address: 'mineplex.com', port: 25565 },
        { name: '2b2t', address: '2b2t.org', port: 25565 }
      ];

      for (const server of exampleServers) {
        try {
          await this.addServer(server.name, server.address, server.port);
        } catch (error) {
          console.error(`Failed to add example server ${server.name}:`, error);
        }
      }
    } catch (error) {
      console.error('Failed to add example servers:', error);
    }
  }
}