#!/bin/bash

echo "=== MCMonitor 平板运行脚本 ==="
echo ""

# 检查项目结构
echo "1. 检查项目结构..."
if [ -f "build-profile.json5" ]; then
    echo "✓ build-profile.json5 存在"
else
    echo "✗ build-profile.json5 不存在"
    exit 1
fi

if [ -f "entry/src/main/module.json5" ]; then
    echo "✓ module.json5 存在"
else
    echo "✗ module.json5 不存在"
    exit 1
fi

echo ""

# 检查设备支持
echo "2. 检查平板设备支持..."
if grep -q "tablet" "entry/src/main/module.json5"; then
    echo "✓ 应用已配置支持平板设备"
else
    echo "✗ 应用未配置平板支持"
    exit 1
fi

echo ""

# 构建项目
echo "3. 构建项目..."
hvigor assembleHap
if [ $? -eq 0 ]; then
    echo "✓ 项目构建成功"
else
    echo "✗ 项目构建失败"
    exit 1
fi

echo ""
echo "=== 运行准备完成 ==="
echo ""
echo "下一步操作："
echo "1. 在 DevEco Studio 中选择 'Debug_Tablet' 配置"
echo "2. 连接您的 HarmonyOS 平板设备"
echo "3. 点击运行按钮（绿色三角形）"
echo "4. 选择平板设备进行部署"
echo ""
echo "如果遇到问题，请参考 '运行配置说明.md' 文件"