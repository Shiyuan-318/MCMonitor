// HarmonyOS 平板运行配置检查脚本
// 运行此脚本检查平板配置是否完整

const fs = require('fs');
const path = require('path');

console.log('🔍 开始检查HarmonyOS平板运行配置...\n');

// 检查运行配置文件
const runConfigDir = '.idea/runConfigurations';
const requiredConfigs = ['Debug_Tablet.xml', 'Release_Tablet.xml'];

console.log('📁 检查运行配置文件:');
requiredConfigs.forEach(config => {
    const configPath = path.join(runConfigDir, config);
    if (fs.existsSync(configPath)) {
        console.log(`✅ ${config} - 存在`);
        
        // 检查配置内容
        const content = fs.readFileSync(configPath, 'utf8');
        if (content.includes('MODULE_NAME') && content.includes('entry')) {
            console.log(`   📋 MODULE_NAME配置正确`);
        } else {
            console.log(`   ⚠️  MODULE_NAME配置需要检查`);
        }
    } else {
        console.log(`❌ ${config} - 缺失`);
    }
});

// 检查module.json5平板配置
console.log('\n📱 检查平板设备配置:');
const moduleJsonPath = 'entry/src/main/module.json5';
if (fs.existsSync(moduleJsonPath)) {
    const moduleJson = fs.readFileSync(moduleJsonPath, 'utf8');
    if (moduleJson.includes('"tablet"')) {
        console.log('✅ module.json5已配置平板设备支持');
    } else {
        console.log('❌ module.json5未配置平板设备支持');
    }
} else {
    console.log('❌ module.json5文件不存在');
}

// 检查页面适配
console.log('\n🎨 检查平板布局适配:');
const indexPagePath = 'entry/src/main/ets/pages/Index.ets';
if (fs.existsSync(indexPagePath)) {
    const indexContent = fs.readFileSync(indexPagePath, 'utf8');
    const checks = [
        { name: '平板布局检测', keyword: 'isTabletLayout' },
        { name: '响应式设计', keyword: 'TABLET_BREAKPOINT' },
        { name: '平板导航', keyword: 'TabletNavigation' }
    ];
    
    checks.forEach(check => {
        if (indexContent.includes(check.keyword)) {
            console.log(`✅ ${check.name} - 已实现`);
        } else {
            console.log(`⚠️  ${check.name} - 需要优化`);
        }
    });
} else {
    console.log('❌ Index.ets文件不存在');
}

console.log('\n📋 配置检查完成！');
console.log('\n🚀 下一步操作:');
console.log('1. 连接HarmonyOS平板设备到电脑');
console.log('2. 在DevEco Studio中选择Debug_Tablet运行配置');
console.log('3. 点击运行按钮部署应用到平板');
console.log('4. 验证平板布局适配效果');

console.log('\n💡 提示:');
console.log('- 确保平板已开启开发者模式和USB调试');
console.log('- 检查HarmonyOS SDK版本兼容性');
console.log('- 如需横竖屏适配，请进一步优化onWindowStageSize回调');